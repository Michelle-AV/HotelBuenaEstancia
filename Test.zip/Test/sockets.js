// const express = require('express');
// const app = express();
// // Crear un servidor HTTP utilizando la aplicación Express
// const server = require('http').createServer(app);

// // Importar la biblioteca 'socket.io' y pasarle el servidor HTTP para establecer la conexión WebSocket
// const io = require('socket.io')(server,{
//   allowEIO3: true,
//   cors: {
//     origin: "http://localhost:5173", 
// 	credentials: true,
//     methods: ["GET", "POST"]
//   }
// });

// // Manejar eventos de conexión a través de WebSocket
// io.on('connection', (socket) => {
//   console.log('User connected');

//   //Evento de desconexion
//   socket.on('disconnect', () => {
//     console.log('User disconnected');
//   });

//   socket.on('chat message', (msg) => {
//     if (msg === '1') {
//       // Realizar una consulta a la base de datos PostgreSQL
//       const pgp = require('pg-promise')();
//       // Conectar a la base de datos 'bdlogin' con el usuario 'postgres' y contraseña '1'
//       const db = pgp('postgres://postgres:1@localhost:5432/hotelbuenaestancia');

//       db.any('select * from clientes;')
//         .then(data => {
//           // Enviar los datos recuperados a través de WebSocket
//           io.emit('database result', data);
//           console.log('Datos de la base de datos enviados al cliente.');
//         })
//         .catch(error => {
//           console.error('Error al consultar la base de datos:', error);
//         });
//     }


//   });  
// });

// server.listen(5100, () => {
//   console.log('Listening on *:5100');
// });



const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server, {
  allowEIO3: true,
  cors: {
    origin: "http://localhost:5173",
    credentials: true,
    methods: ["GET", "POST"]
  }
});

io.on('connection', (socket) => {
  console.log('User connected');

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });

  socket.on('chat message', (msg) => {

    console.log('Received message:', msg);

    if (msg === '1') {
      // Consulta 1
      const pgp = require('pg-promise')();
      const db = pgp('postgres://postgres:1@localhost:5432/hotelbuenaestancia');

      db.any('select * from clientes;')
        .then(data => {
          io.emit('database result', data);
          console.log('Datos de la base de datos enviados al cliente.');
        })
        .catch(error => {
          console.error('Error al consultar la base de datos:', error);
        });
    } else if (msg === '2') {
      // Consulta 2
      const pgp = require('pg-promise')();
      const db = pgp('postgres://postgres:1@localhost:5432/hotelbuenaestancia');

      db.any('select * from otra_tabla;')
        .then(data => {
          io.emit('database result', data);
          console.log('Otra consulta de la base de datos enviada al cliente.');
        })
        .catch(error => {
          console.error('Error al consultar la otra tabla de la base de datos:', error);
        });
    }
  });
});

server.listen(5100, () => {
  console.log('Listening on *:5100');
});

const { count } = require('console');
const { Socket } = require('socket.io');

const express = require('express');
const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http); //Conexion al server

//-------------
// Variable para almacenar el tiempo de inicio de conexión

//---------------


http.listen(5300, () => {
  console.log("listening on *:5300");
});

app.use(express.static(__dirname + '/views'))

//---CODIGO PARA MOSTRAR EL TIEMPO DE CONEXION DE UN CLIENTE------
// Middleware para realizar un seguimiento del tiempo de conexión
io.use((socket, next) => {
  socket.connectionStartTime = Date.now();
  next();
});

io.on('connection', (socket) => {
  const connectionStartTime = socket.connectionStartTime;
  const connectionTime = Date.now() - connectionStartTime;

  console.log(`Cliente se conectó en ${connectionTime} ms.`);
  
  // Envía un mensaje al cliente para confirmar la conexión
  socket.emit('connection_message', 'Conexión establecida con el servidor.');
  
  // Maneja otros eventos de socket aquí
  
  // Evento para desconexión del cliente
  socket.on('disconnect', () => {
    console.log('Cliente desconectado.');
  });
});



//------------------
module.exports = app;





